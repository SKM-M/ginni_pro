<?php
include "Register.php";
$reg = new Register();
 $chkdata = array();
if(!empty($_POST) && isset($_POST)){
$_POST = array_map('trim', $_POST); 
	$chkdata  = array(
		 'Email'=> htmlspecialchars($_POST['email']),
		 'Password'=> htmlspecialchars($_POST['password']),		 
		 'College'=> htmlspecialchars($_POST['college'])
		);

$result = $reg->InsertUser($chkdata['Email'], $chkdata['Password'],$chkdata['College']);
echo $result ;
	
}

?>