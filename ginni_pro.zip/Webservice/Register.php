<?php
class Register {
    private $password;
    public $email;
    public $college;
    
    public function InsertUser($email,$password,$college) {
	$connect = mysql_pconnect("localhost","supposg7","Apple2018");
	if ($connect) {       
    		if(mysql_select_db("supposg7_Ginni", $connect)) {
      		  $query = "  INSERT INTO register (student_email,password,institute_name) VALUES
      	              ( '".$email."', '".md5($password)."', '".$college."')";
       		 if ($res = mysql_query($query)) 
				return "{'result':true}";
       		 else
			   return "{'result':false}";
		}
    }else{
		return  "{'result':false}";
	}
}

}
?>