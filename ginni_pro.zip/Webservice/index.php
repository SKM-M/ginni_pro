<?php
ini_set('error_reporting', E_STRICT);
require_once('lib/nusoap.php'); 


$server = new soap_server();

$server->configureWSDL('Ginni Web Services', 'urn:Ginni Web Services');

$server->soap_defencoding = 'UTF-8';

$server->register(
    'InsertUser',
    array('Email' => 'xsd:string', 'password'=>'xsd:string','College' => 'xsd:string'),
    array('return' =>'xsd:boolean'),
    'Ginni Web Services',
    'Ginni Web Services#InsertUser',
    'rpc',
    'literal'    
); //description


$request = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
$server->service($request);

?>