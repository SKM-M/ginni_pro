<?php 

$DB_USER="supposg7";
$DB_PWD="Apple2018";
$DB_NAME="supposg7_Ginni";

$link=mysql_connect('localhost',$DB_USER,$DB_PWD);

mysql_select_db($DB_NAME,$link);

define('BASE_URL','http://www.support-4-pc.com/clients/ginni');

define('DS',DIRECTORY_SEPARATOR);


?>
